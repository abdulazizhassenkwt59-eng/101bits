#!/usr/bin/env python3
import os
import sys
import time

OP_MOV_A  = 1
OP_ADD    = 2
OP_SHELL  = 3
OP_HTTP   = 4
OP_UI     = 5
OP_JMP    = 6
OP_VIBE   = 7
OP_STR    = 97

def execute_bytecode(file_path, is_dev=False):
    try:
        with open(file_path, 'rb') as f:
            content = f.read()

        idx = 0
        for line in content.split(b'\n'):
            idx += len(line) + 1
            if line.decode('utf-8', errors='ignore').strip() == "[BINARY_START]": break
            
        virtual_ram = bytearray(content[idx:])
        
        REG_A, REG_B, REG_C, PC = 0, 0, 0, 0
        
        if is_dev:
            print("\x1b[1;35m┌─── [101BITS REAL-TIME DEBUGLOG PIPELINE] ──────────────────────────┐\x1b[0m")
            print(f"│ Total Payload Matrix Size: {len(virtual_ram)} executable microcode storage buffer bytes. │")
            print("└───────────────────────────────────────────────────────────────────┘")
            
        while PC < len(virtual_ram):
            opcode = virtual_ram[PC]
            
            if is_dev:
                hex_dump = " ".join(f"{b:02X}" for b in virtual_ram[max(0, PC-2):PC+4])
                print(f"📍 \x1b[1;33m[PC: {PC:03d}]\x1b[0m Byte: \x1b[1;32m0x{opcode:02X}\x1b[0m | Matrix: [A:{REG_A:03d} B:{REG_B:03d} C:{REG_C:03d}] | Hex: ... {hex_dump} ...")
                time.sleep(0.04)
                
            if opcode == OP_MOV_A:
                REG_B = REG_A
                REG_A = virtual_ram[PC + 1]
                PC += 2
            elif opcode == OP_ADD:
                REG_C = (REG_A + REG_B) & 0xFF
                if not is_dev:
                    print(f"🧮 [Virtual CPU Add]: {REG_A} + {REG_B} = {REG_C}")
                PC += 1
            elif opcode == OP_SHELL:
                os.system(virtual_ram[PC + 1:].decode('utf-8', errors='ignore').strip())
                break
            elif opcode == OP_JMP:
                target_address = virtual_ram[PC + 1]
                if target_address < len(virtual_ram): PC = target_address
                else: break
            elif opcode == OP_VIBE:
                os.system("cmd notification vibrate 100 > /dev/null 2>&1")
                PC += 1
            elif opcode == OP_UI:
                clean_msg = virtual_ram[PC + 1:].decode('utf-8', errors='ignore').strip().replace("'", "")
                os.system(f"dialog --title '101Bits Virtual Core Window' --msgbox '{clean_msg}' 10 52")
                break
            elif opcode == OP_STR:
                print(f"🚀 [Output]: {virtual_ram[PC + 1:].decode('utf-8', errors='ignore')}")
                break
            else:
                PC += 1
                
        if is_dev:
            print("\n🏁 \x1b[1;35m[Sandbox Process Trace Completed]\x1b[0m")
            print(f"📈 States -> Reg A: {REG_A} | Reg B: {REG_B} | Storage C: {REG_C}")
            
    except Exception as e:
        print(f"❌ Core Execution Halt Trace Exception: {str(e)}")
