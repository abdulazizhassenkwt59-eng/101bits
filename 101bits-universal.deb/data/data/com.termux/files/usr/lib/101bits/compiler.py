#!/usr/bin/env python3
import os
import sys

def compile_source(src, dest):
    if not os.path.exists(src):
        print(f"❌ Error: Source assembly template file '{src}' not found.")
        sys.exit(1)
        
    print(f"⚡ [101Bits Custom Tool Assembler Engine Initializing...]")
    try:
        compiled_bytes = bytearray()
        with open(src, 'r') as f:
            for line_no, line in enumerate(f, 1):
                tokens = line.strip().split()
                if not tokens or tokens[0].startswith(";"): continue
                
                cmd = tokens[0].upper()
                if cmd == "MOV":
                    compiled_bytes.append(1) # OP_MOV_A
                    compiled_bytes.append(int(tokens[1]) & 0xFF)
                elif cmd == "ADD":
                    compiled_bytes.append(2) # OP_ADD
                elif cmd == "JMP":
                    compiled_bytes.append(6) # OP_JMP
                    compiled_bytes.append(int(tokens[1]) & 0xFF)
                elif cmd == "VIBE":
                    compiled_bytes.append(7) # OP_VIBE
                elif cmd == "UI":
                    compiled_bytes.append(5) # OP_UI
                    compiled_bytes.extend(" ".join(tokens[1:]).encode('utf-8'))
                elif cmd == "SHELL":
                    compiled_bytes.append(3) # OP_SHELL
                    compiled_bytes.extend(" ".join(tokens[1:]).encode('utf-8'))
                else:
                    print(f"⚠️  Syntax Warning line {line_no}: Mnemonic '{cmd}' skipped.")
                    
        header = b"IGNORE: High-Performance Compiled Sandbox Code\n[BINARY_START]\n"
        with open(dest, 'wb') as out_f:
            out_f.write(header + compiled_bytes)
        print(f"📦 [Assembler Build Success]: Generated: \x1b[1;32m{dest}\x1b[0m")
    except Exception as asm_err:
        print(f"❌ Structural Compilation Interruption: {str(asm_err)}")
